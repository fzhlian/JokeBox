// Script for compiling build behavior.
const { appTasks } = require('C:/Users/fzhlian/.hvigor/project_caches/2bf22346994211b5d65a78c952167251/workspace/node_modules/@ohos/hvigor-ohos-plugin');
export { appTasks };
